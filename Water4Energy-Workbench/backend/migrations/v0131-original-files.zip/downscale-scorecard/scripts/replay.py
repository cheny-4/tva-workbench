"""File-backed Water4Energy replay. No network, subprocesses, training, or jobs."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import runpy
import shutil

TASKS = ('lab.literature', 'lab.download', 'lab.ledger', 'lab.board', 'lab.design',
         'lab.show_command', 'lab.realize', 'downscale.scorecard')
CASE = {'start': '2019-04-16', 'end': '2019-04-22', 'issued': '2019-04-15'}
ROOT = Path(__file__).resolve().parents[1]
SOURCES = ROOT / 'references'
HW = SOURCES / 'HEADWATER'
EX = SOURCES / 'water4energy_experiment'
MANIFEST = 'tva-demo-20190416-20190422.json'

def read(path):
    return path.read_text(encoding='utf-8')

def load(path):
    return json.loads(read(path))

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')

def provenance(path):
    rel = path.relative_to(SOURCES).as_posix()
    repo, name = rel.split('/', 1)
    matches = [r for r in load(ROOT / 'source-provenance.json') if r['repo'] == repo and r['path'] == name]
    if len(matches) != 1:
        raise ValueError('Unregistered source: ' + rel)
    record = matches[0]
    if hashlib.sha256(path.read_bytes()).hexdigest() != record['sha256']:
        raise ValueError('Source hash mismatch: ' + rel)
    return record

def stage_research(out):
    files = {
        'experiment_ledger.json': HW / 'hypothesis_lab/experiment_ledger.json',
        'proposer_brief.md': HW / 'hypothesis_lab/runs/20261018_iter1_april/PROPOSER_BRIEF.md',
        'critique.json': HW / 'hypothesis_lab/runs/20261018_iter1_april/critique.json',
        'referee_brief.md': HW / 'hypothesis_lab/runs/20261018_iter1_april/referee_brief.md',
        'experiments.json': HW / 'hypothesis_lab/runs/20261018_iter1_april/experiments.json',
    }
    for name, source in files.items():
        provenance(source)
        shutil.copyfile(source, out / name)
    write_json(out / 'w4e-source-provenance.json', load(ROOT / 'source-provenance.json'))
    return {'ledger_file': 'experiment_ledger.json', 'proposal_file': 'proposer_brief.md',
            'critic_file': 'critique.json', 'referee_file': 'referee_brief.md',
            'protocol_file': 'experiments.json'}

def update_manifest(out, panels):
    path = out / MANIFEST
    manifest = load(path) if path.exists() else {'schema_version': 1, 'example_only': False, 'case': CASE, 'panels': {}}
    if manifest.get('case') != CASE or manifest.get('example_only') is not False:
        raise ValueError('Existing manifest is for a different case or is an example.')
    manifest['panels'].update(panels)
    manifest['research'] = stage_research(out)
    write_json(path, manifest)

def realization(out):
    panels = {}
    for panel, variable, observed, stored, model, units in [
        ('temperature', 't2m', 17.3, 18.2, 18.0, 'degrees Celsius'),
        ('precipitation', 'precip', 55.9, 24.4, 24.7, 'mm'),
    ]:
        source = HW / f'figures/april2019_temporal_reslim/tva_{variable}_20190415_reference_obs_k9_reslim_temporal.png'
        figure = f'w4e-april-{panel}.png'
        backing = f'w4e-april-{panel}-source.json'
        records = [provenance(source), provenance(HW / 'scripts/plot_april2019_temporal_reslim.py'),
                   provenance(HW / 'scripts/plot_obs_target_comparison.py')]
        shutil.copyfile(source, out / figure)
        write_json(out / backing, {
            'case': CASE, 'kind': 'frozen_prediction', 'model': 'det_v2_soil_k9',
            'figure': figure, 'source_material': records,
            'values_from_published_figure_labels': {'units': units, 'observed_valley': observed,
                'stored_1979_2017_week_valley': stored, 'residual_9x9_valley': model},
            'scope': 'Single valid week. Values transcribed from the original published map labels, not recomputed from arrays.',
            'column_mapping': 'plot_obs_target_comparison.py maps Residual 9×9 to runs/det_v2_soil_k9.',
            'other_columns': 'The unmodified source figure also contains saved Reslim comparisons; these are not a claim about the current model.',
            'aggregate_score_warning': 'The four-week 2019 valley RMSE of 0.767 K is not a score for this single April week.',
        })
        panels[panel] = {'kind': 'frozen_prediction', 'model': 'det_v2_soil_k9',
            'figure': figure, 'source_file': backing,
            'source': 'Original HEADWATER April map; Residual 9×9 column is det_v2_soil_k9. Other saved comparison columns retained.'}
    source = HW / 'hypothesis_lab/runs/20261102_sro_sample/receipt.json'
    receipt = load(source)
    rows = [row for row in receipt['files'] if row['issue'] == CASE['issued']]
    if len(rows) != 1:
        raise ValueError('The committed ERA5 receipt does not contain exactly one April case.')
    row = rows[0]
    backing = 'w4e-april-runoff-source.json'
    figure = 'w4e-april-runoff-receipt.png'
    write_json(out / backing, {'case': CASE, 'kind': 'observation', 'dataset': 'ERA5', 'variable': 'sro',
        'forecast_available': False, 'receipt_written_at': receipt['written_at'], 'receipt_row': row,
        'source_material': [provenance(source), provenance(HW / 'scripts/insert_sro_into_sample.py')],
        'scope': 'Valley mean of the 7-day accumulated ERA5 surface runoff, in mm, from the committed receipt. Not a spatial map.',
        'window': 'insert_sro_into_sample.py uses issue +1 through issue +7 days.',
        'raw_arrays_in_bundle': False, 'new_inference': False})
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(9, 4.8))
    fig.subplots_adjust(left=.16, right=.96, bottom=.28, top=.76)
    ax.barh(['ERA5 observed'], [row['valley_week_mm']], color='#00662c', height=.4)
    ax.set_xlim(0, max(9, row['valley_week_mm'] * 1.23))
    ax.set_ylim(-.8, .8)
    ax.text(row['valley_week_mm'] + .15, 0, f"{row['valley_week_mm']:.3f} mm", va='center', fontsize=14)
    ax.set_xlabel('Valley mean weekly accumulated surface runoff (mm)')
    ax.set_title('16–22 April 2019 · ERA5 surface runoff\nCommitted observation receipt; HEADWATER forecast unavailable', loc='left', pad=22)
    ax.spines[['top', 'right']].set_visible(False)
    fig.text(.16, .06, 'Source: HEADWATER 20261102_sro_sample/receipt.json · 3 November 2026\nReceipt summary only; spatial arrays are not included.', fontsize=9, color='#55616c')
    fig.savefig(out / figure, dpi=160, bbox_inches='tight', facecolor='white', metadata={'Source': provenance(source)['url']})
    plt.close(fig)
    panels['runoff'] = {'kind': 'observation', 'dataset': 'ERA5', 'variable': 'sro', 'forecast_available': False,
        'figure': figure, 'source_file': backing,
        'source': 'ERA5 sro observation: committed 7-day valley summary receipt. Summary chart, not a spatial map; no runoff forecast.'}
    update_manifest(out, panels)
    return {'case': CASE, 'panels': panels, 'display_files': [p['figure'] for p in panels.values()],
            'new_inference': False, 'runoff_scope': 'Receipt-derived valley summary; original spatial runoff arrays are not staged.'}

def downscale(out):
    source = EX / 'Trial0_run_20260907_220510_scorecard_ext.json'
    scorecard = load(source)
    if scorecard.get('wet_day', {}).get('date') != '2019-04-19' or 'run_20260907_220510_trial0_unet' not in scorecard.get('ckpt', ''):
        raise ValueError('Trial 0 source identity/date mismatch.')
    figures = []
    materials = [provenance(source)]
    for variable in ['tp', 't2m']:
        image = EX / f'figures/trial0_test_wet_2019-04-19_{variable}.png'
        name = f'w4e-trial0-20190419-{variable}.png'
        shutil.copyfile(image, out / name)
        materials.append(provenance(image))
        figures.append(name)
    backing = 'w4e-trial0-scorecard-source.json'
    write_json(out / backing, {'case': CASE, 'trial': 'Trial 0', 'scored': '2026-09-07',
        'date': '2019-04-19', 'input_resolution_deg': 1, 'output_resolution_deg': .25,
        'source_material': materials, 'original_scorecard': scorecard,
        'score_scope': 'Original aggregate standardized test-split scores over 730 days. Not an April-only or one-day re-score.',
        'figure_scope': 'Existing wet test day 19 April 2019. U-Net, bilinear and persistence shown in the original figure.',
        'new_training': False, 'new_scoring': False})
    panel = {'kind': 'frozen_comparison', 'trial': 'Trial 0', 'scored': '2026-09-07',
        'date': '2019-04-19', 'input_resolution_deg': 1, 'output_resolution_deg': .25,
        'figure': figures[0], 'source_file': backing,
        'source': 'Original Trial 0 wet-day map, 19 April 2019; original aggregate scorecard scored 7 September 2026. No retrain or re-score.'}
    update_manifest(out, {'downscale': panel})
    return {'panel': panel, 'score_scope': 'Aggregate test split; not an April-only score.',
            'scores': scorecard['scores'], 'display_files': figures}

def run(task, out, context='tva'):
    out.mkdir(parents=True, exist_ok=True)
    research = stage_research(out)
    if task == 'lab.realize':
        result = realization(out)
    elif task == 'downscale.scorecard':
        result = downscale(out)
    elif task == 'lab.ledger':
        ledger = load(HW / 'hypothesis_lab/experiment_ledger.json')
        result = {'snapshot_updated': ledger.get('updated'), 'source': provenance(HW / 'hypothesis_lab/experiment_ledger.json'),
            'rows': [{k: row[k] for k in ['id', 'status', 'hypothesis_status', 'blocks_reproposal', 'conclusion'] if k in row}
                     for row in ledger['runs']], 'open_gaps': ledger.get('open_gaps'), 'display_files': [research['ledger_file']]}
    elif task == 'lab.board':
        script = HW / 'hypothesis_lab/scripts/board.py'
        provenance(script)
        namespace = runpy.run_path(str(script), run_name='water4energy_read_only_board')
        result = {'source': provenance(HW / 'hypothesis_lab/board.json'),
            'board': namespace['render'](load(HW / 'hypothesis_lab/board.json'), show_all=True, root=HW),
            'snapshot_only': True, 'jobs_submitted': 0}
        result['demo_record'] = {'as_of': '2026-11-12',
            'source': provenance(SOURCES / 'water4energy_SC26Demo/Water4Energy_Workbench_Actions_20261112.md'),
            'H100_training_flag': False, 'Lux_training_flag': False,
            'rows': [
                {'item': 'April rain rank', 'where': 'Frontier', 'record': 'Reads the soil files. No GPU.'},
                {'item': 'Lux device check', 'where': 'Lux, one MI355X', 'record': 'Prints the device name. Does not train.'},
                {'item': 'Column water E_tcwv_9x9', 'where': 'Designed', 'record': 'Waits on the rank file and a person.'},
                {'item': '90-day daily filter', 'where': 'Designed', 'record': 'An odd temporal kernel cannot see all 90 days.'},
                {'item': 'Temporal attention along the 90 days', 'where': 'Not a row', 'record': 'No script and no board row.'},
            ], 'note': 'Supplied demo record; distinguish it from the older original board.json snapshot and from live scheduler status.'}
    elif task in ('lab.literature', 'lab.download'):
        with (HW / 'docs/literature/catalog.csv').open(encoding='utf-8', newline='') as handle:
            catalog = list(csv.DictReader(handle))
        result = {'catalog': catalog, 'source': provenance(HW / 'docs/literature/catalog.csv'),
            'download_status_document': read(HW / 'docs/literature/DOWNLOAD.md'),
            'missing_pdf_document': read(HW / 'docs/literature/MISSING_PDFS.md'),
            'pdf_bytes_in_this_bundle': False, 'downloads_performed': 0,
            'note': 'Repository catalog/download records are not a claim that PDFs were copied into this local project.'}
    elif task == 'lab.design':
        folder = '20261106_second_model' if context == 'headwater' else '20261018_iter1_april'
        pack = HW / 'hypothesis_lab/runs' / folder
        result = {'source': provenance(pack / 'experiments.json'),
            'review_context': context, 'saved_review_folder': folder,
            'saved_protocol': load(pack / 'experiments.json'), 'protocol_source': provenance(pack / 'experiments.json'),
            'proposer': load(pack / 'hypotheses.json') if context == 'headwater' else read(out / research['proposal_file']),
            'critic': load(pack / 'critique.json'), 'referee': read(pack / 'referee_brief.md'),
            'scope': 'Latest checked-in review in the staged source set, not a new review or a claim that its model is currently selected.' if context == 'headwater' else 'Archived October review of the fixed April case, not current project status.',
            'mode': 'Read saved review; any newly drafted protocol is a proposal only. No human flag is changed.',
            'display_files': [research[key] for key in ['proposal_file', 'critic_file', 'referee_file', 'protocol_file']]}
    else:
        source = HW / 'lux/train_k9.sh'
        result = {'source': provenance(source), 'existing_command_file': read(source), 'executed': False,
            'trial0_command': None, 'missing': 'The exact original Trial 0 scoring command is not in this staged bundle; do not invent one.'}
    result.update({'contract_id': task, 'case': CASE, 'context': context, 'mode': 'saved-file replay', 'jobs_submitted': 0})
    write_json(out / ('w4e-' + task.replace('.', '-') + '-readout.json'), result)
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--task', required=True, choices=TASKS)
    parser.add_argument('--output', type=Path, default=Path('/mnt/data/output'))
    parser.add_argument('--context', choices=['headwater', 'tva'], default='tva')
    args = parser.parse_args()
    print(json.dumps(run(args.task, args.output, args.context), indent=2, ensure_ascii=False))
